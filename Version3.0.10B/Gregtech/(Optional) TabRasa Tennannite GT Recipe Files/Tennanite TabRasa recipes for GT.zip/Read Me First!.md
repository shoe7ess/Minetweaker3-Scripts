1) Open TabulaRasa.jar mod file in archive viewer (WinRAR for example)
2) Move /assets to the .jar to add in necessary Tennanite blocks/items for use in MineTweaker 3 GregTech script
	2a) Use update mode "Add and replace files"
	2b) Final .jar structure file should be:
		/assets
		   /tabularasa
			  /textures
			      blocks
				  items
		/META-INF
		/tabularasa
3) Move /minecraft/config/cofh/TabulaRasa.cfg to /minecraft folder (TR recipes may need to be added manually dependant on pre-existing TR recipes)